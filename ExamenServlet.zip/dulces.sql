Create database pinatas_examen;

use pinatas_examen;

create table articulos(
   id INT NOT NULL,
   codigo VARCHAR(100) NOT NULL,
   nombre VARCHAR(40) NOT NULL,
   precio DOUBLE NOT NULL
);

select * from articulos;



